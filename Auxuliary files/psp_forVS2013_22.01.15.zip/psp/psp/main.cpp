//
//  main.cpp
//  psp2
//
//  Created by Valentin on 10/7/13.
//  Copyright (c) 2013 Valentin. All rights reserved.
//



#include "Solver.h"
#include "utils.h"

#include <iostream>
#include <fstream>
#include <ctime>



using namespace std;



int main(int argc, const char * argv[])
{
    useCommaInsteadOfPointInConsolOut();
    
    cout << "Start" << endl;
    time_t totalTime; time(&totalTime);
    
    string path = PATH_TO_DATA_FOLDER;
    Solver *solver = new Solver(&path, [](long i, string name){
        return i == 0;
    });
    
    // Kochetov, Stolyar, 2003
//    ParamsKS paramsKS = {
//        .maxIterationNumber = 1000, // 1000-5000
//        .probabilityKP = 0.5f,
//        .probabilitySN = 0.2f, // 0.2
//        .tabuListSize = 5, // 5
//        .changingInterval = 10, // 5-10
//        .numberOfReturnsToRecord = 5 // 5
//    };
//    auto solutionsKS = solver->solveWithScheduleKS(paramsKS);
//    LOG(strSolutions(solutionsKS));
//    LOGF(paramsKS.str() << endl << strTableSolutions(solutionsKS));
    
    // My genetic algorithm
//    ParamsGA paramsGA = {
//        .maxGeneratedSchedules = 5000, // 1000, 5000, 50000
//        .populationSize = 40, // 40
//        .maxParents = 20, // 20
//        .maxChildren = 40, // 40
//        .numberOfChildrenInNextGeneration = 10, // 10
//        .timesPingPong = 100, // 100
//        .probabilityKP = 0.5f, // -
//        .probabilityParentSelection = 0.8f, // 0.8
//        .permissibleResourceRemains = 0.9f, // 0.9
//        .swapAndMovePermissibleTimes = 10 // 10
//    };
//    auto solutionsGA = solver->solveWithScheduleGA(paramsGA);
//    LOG(strSolutions(solutionsGA));
//    LOGF(paramsGA.str() << endl << strTableSolutions(solutionsGA));
    
    // My genetic algorithm, 2014
    ParamsGA paramsGA = {
		maxGeneratedSchedulesInfinite, //.maxGeneratedSchedules = maxGeneratedSchedulesInfinite, // 1000, 5000, 50000
		40, //.populationSize = 40, // 40
		20, //.maxParents = 20, // 20
		40, //.maxChildren = 40, // 40
		10, //.numberOfChildrenInNextGeneration = 10, // 10
		10, //.timesPingPong = 10, // 10
		0.5f, //.probabilityKP = 0.5f, // 0.5
		0.8f, //.probabilityParentSelection = 0.8f, // 0.8
		0.9f, //.permissibleResourceRemains = 0.9f, // 0.9
		10, //.swapAndMovePermissibleTimes = 10 // 10
    };
    ParamsKS paramsKS = {
		100, //.maxIterationNumber = 100, // 0
		0.5f, //.probabilityKP = 0.5f, // 0.5
		0.2f, //.probabilitySN = 0.2f, // 0.2
		1, //.tabuListSize = 1, // 1
		1, //.changingInterval = 1, // 1
		10, //.numberOfReturnsToRecord = 10 // 0
    };
    ParamsCross paramsCross = {
		0.9f, //.permissibleResourceRemains = 0.9f, // 0.9
		0.5f, //.probabilityKP = 0.5f, // 0.5
		true, //.withNet = true, // true
		false, //.isEarlyComposite = false // false
    };
    int permissibleNoChangeRecord = 10;
    int numberOfSubstitutions = 10;
    int numberOfLocalSearchKS = 10;
    auto solutionsGA2014 = solver->solveWithScheduleGA2014(paramsGA,
                                                           paramsKS,
                                                           paramsCross,
                                                           permissibleNoChangeRecord,
                                                           numberOfSubstitutions,
                                                           numberOfLocalSearchKS);
    LOG(strSolutions(solutionsGA2014));
    LOGF(strParamsGA2014(paramsGA,
                         paramsKS,
                         paramsCross,
                         permissibleNoChangeRecord,
                         numberOfSubstitutions,
                         numberOfLocalSearchKS)
         << endl << strTableSolutions(solutionsGA2014));
    
    delete solver;
    
    cout << "Finish. Total time =  " << time(NULL) - totalTime << "sec." << endl;
    return 0;
}
